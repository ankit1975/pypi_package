practice by self
testing only
